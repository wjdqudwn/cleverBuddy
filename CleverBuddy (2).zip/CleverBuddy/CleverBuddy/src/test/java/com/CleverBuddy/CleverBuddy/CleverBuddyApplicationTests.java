package com.CleverBuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleverBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
