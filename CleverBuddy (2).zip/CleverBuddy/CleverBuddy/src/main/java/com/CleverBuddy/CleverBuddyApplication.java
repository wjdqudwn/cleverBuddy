package com.CleverBuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleverBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleverBuddyApplication.class, args);
	}

}
